from __future__ import annotations

from backend.app.agents.claim_agent.agent import ClaimAgent
from backend.app.agents.conflict_agent.agent import ConflictAgent
from backend.app.agents.evidence_agent.agent import EvidenceAgent
from backend.app.agents.independence_agent.agent import IndependenceAgent
from backend.app.agents.research_agent.agent import ResearchAgent
from backend.app.agents.source_agent.agent import SourceAgent
from backend.app.agents.verdict_agent.agent import VerdictAgent
from backend.app.agents.verification_agent.agent import VerificationAgent
from backend.app.core.constants import RESEARCH_MAX_ITERATIONS
from backend.app.core.logging import get_logger
from backend.app.workflows.graph import Graph

logger = get_logger(__name__)


def build_investigation_workflow() -> Graph:
    """claim -> research -> source -> evidence (YOUR TEAM'S WORK ENDS HERE)
    
    NOTE: Verification, conflict detection, independence analysis, and verdict generation
    are disabled until the other team implements them. Investigations will complete after
    evidence extraction and show evidence without a final verdict.
    """
    graph = Graph()
    
    # YOUR TEAM: Agents 1-4 (Claim, Research, Source, Evidence)
    steps = [
        ("claim_extraction", ClaimAgent()),
        ("research", ResearchAgent(max_iterations=RESEARCH_MAX_ITERATIONS, queries_per_round=1, results_per_query=3, min_results_per_claim=3)),
        ("source_evaluation", SourceAgent()),
        ("evidence_extraction", EvidenceAgent()),
        # OTHER TEAM: Agents 5-8 (Verification, Conflict, Independence, Verdict) - DISABLED FOR NOW
        # ("verification", VerificationAgent()),
        # ("conflict_detection", ConflictAgent()),
        # ("independence_analysis", IndependenceAgent()),
        # ("verdict_generation", VerdictAgent()),
    ]
    
    for name, agent in steps:
        graph.add_node(name, agent.execute)
    for (a, _), (b, _) in zip(steps, steps[1:]):
        graph.add_edge(a, b)
    graph.set_entry_point(steps[0][0])
    logger.info("Investigation workflow graph built (stops after evidence extraction)")
    return graph
